﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BattleshipGame
{
    public class Game
    {
        Board playerBoard;
        Board computerBoard;
        public void Start()
        {
            playerBoard = new Board(8);
            computerBoard = new Board(8);

            computerBoard.PlaceShip(2, 3);
            playerBoard.PlaceShip(1, 1);

            ShowWelcomeMessage();
            setup();
            RunGameLoop();
            ShowGameOverMessage();
        }

        private void ShowWelcomeMessage()
        {
            Console.WriteLine("=================================");
            Console.WriteLine("         BATTLESHIP GAME         ");
            Console.WriteLine("=================================");
            Console.WriteLine("\nVERSION: 0.2 - ARROW INPUTS");
            Console.WriteLine("Sink all enemy ships to win!");
            Console.WriteLine();
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();
            Console.Clear();
        }

        private void setup()
        {
            int x = 0;
            int y = 0;
            int lastX = 7;
            int lastY = 7;
            bool isSetup = true;
            bool shipOrient = true;

            while (isSetup)
            {
                // Initiate Board
                playerBoard.Cursor(y, x, lastY, lastX);
                Console.WriteLine("Use ARROWS to place ships.");
                Console.WriteLine("Use SPACEBAR to rotate ships");
                Console.WriteLine("\n--- Player Board ---");
                playerBoard.Display(false);

                if (lastX != x) { lastX = x; }
                if (lastY != y) { lastY = y; }

                Console.WriteLine("\nCurrent selection at " + x + ", " + y);
                Console.Write("Current Orientation = ");
                if (shipOrient) { Console.WriteLine("Horizontal"); }
                else { Console.WriteLine("Vertical"); }

                Console.WriteLine("\nPress ENTER when finished");

                // Read input
                if (Console.ReadKey().Key == ConsoleKey.Spacebar) { shipOrient = shipOrient == false; }
                if ((Console.ReadKey().Key == ConsoleKey.DownArrow) && y < 8) { y++; }
                if ((Console.ReadKey().Key == ConsoleKey.UpArrow) && y > 0) { y--; }
                if ((Console.ReadKey().Key == ConsoleKey.RightArrow) && x < 8) { x++; }
                if ((Console.ReadKey().Key == ConsoleKey.LeftArrow) && x > 0) { x--; }
                if (Console.ReadKey().Key == ConsoleKey.Enter) { isSetup = false; }

                Console.Clear();
            }
        }

        private void RunGameLoop()
        {
            bool gameOver = false;
            bool playerTurn = true;
            int turnCounter = 1;

            while (!gameOver)
            {
                Console.WriteLine("=================================");
                Console.WriteLine($"Turn #{turnCounter}");
                Console.WriteLine("=================================");

                if (playerTurn)
                {
                    PlayerTurn();

                    Console.WriteLine("\n--- Computer Board ---");
                    computerBoard.Display(true); // hide ships
                }
                else
                {
                    ComputerTurn();

                    Console.WriteLine("\n--- Player Board ---");
                    playerBoard.Display(false); // show ships
                }

                // Temporary win condition (for testing)
                if (turnCounter == 10)
                {
                    gameOver = true;
                }

                playerTurn = !playerTurn;
                turnCounter++;

                Console.WriteLine();
                Console.WriteLine("Press any key for next turn...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        private void PlayerTurn()
        {
            int x = 0;
            int y = 0;
            int lastX = 7;
            int lastY = 7;
            bool isTurn = true;

            while (isTurn)
            {
                computerBoard.Cursor(y, x, lastY, lastX);

                // Display info
                Console.WriteLine("PLAYER TURN");
                Console.WriteLine("Use ARROWS to select target.");
                Console.WriteLine("Use SPACEBAR to fire.");
                Console.WriteLine("\n--- Computer Board ---");
                computerBoard.Display(true); // hide ships
                Console.WriteLine("\nCurrent selection at " + x + ", " + y);

                if (lastX != x) { lastX = x; }
                if (lastY != y) { lastY = y; }

                // Read input
                if ((Console.ReadKey().Key == ConsoleKey.DownArrow) && y < 8) { y++; }
                if ((Console.ReadKey().Key == ConsoleKey.UpArrow) && y > 0) { y--; }
                if ((Console.ReadKey().Key == ConsoleKey.RightArrow) && x < 8) { x++; }
                if ((Console.ReadKey().Key == ConsoleKey.LeftArrow) && x > 0) { x--; }

                if (Console.ReadKey().Key == ConsoleKey.Spacebar)
                {
                    computerBoard.Attack(y, x);
                    isTurn = false;
                }
                Console.Clear();
            }
        }

        private void ComputerTurn()
        {
            Console.WriteLine("COMPUTER TURN");

            Random rand = new Random();
            int row = rand.Next(0, 8);
            int col = rand.Next(0, 8);

            playerBoard.Attack(row, col);


        }

        private int GetValidNumber(string prompt)
        {
            int number;
            bool valid;

            do
            {
                Console.Write(prompt);
                valid = int.TryParse(Console.ReadLine(), out number);

                if (!valid || number < 0 || number > 7)
                {
                    Console.WriteLine("Invalid input. Enter a number between 0 and 7.");
                }

            } while (!valid || number < 0 || number > 7);

            return number;
        }

        private void ShowGameOverMessage()
        {
            Console.WriteLine("=================================");
            Console.WriteLine("            GAME OVER            ");
            Console.WriteLine("=================================");
        }
    }
}