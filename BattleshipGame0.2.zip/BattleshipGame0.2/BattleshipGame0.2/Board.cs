﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipGame
{
    public class Board
    {
        private char[,] grid;

        public Board(int size)
        {
            grid = new char[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    grid[row, col] = '~'; // water
                }
            }
        }
        public void PlaceShip(int row, int col)
        {
            grid[row, col] = 'S';
        }

        public void Display(bool hideShips)
        {
            for (int row = 0; row < grid.GetLength(0); row++)
            {
                for (int col = 0; col < grid.GetLength(1); col++)
                {
                    char symbol = grid[row, col];

                    // Hide ships if needed
                    if (hideShips && symbol == 'S')
                    {
                        Console.Write("~ ");
                    }
                    else
                    {
                        Console.Write(symbol + " ");
                    }
                }
                Console.WriteLine();
            }
        }
        public void Attack(int row, int col)
        {
            if (grid[row, col] == 'S')
            {
                grid[row, col] = 'X'; // hit
                Console.WriteLine("Hit!");
            }
            else if (grid[row, col] == '~')
            {
                grid[row, col] = 'O'; // miss
                Console.WriteLine("Miss!");
            }
        }

        public void Cursor(int row, int col, int lastRow, int lastCol)
        {
            grid[row, col] = '*'; // Cursor
            grid[lastRow, lastCol] = '~'; // Resets Grid Square
        }
    }
}

