﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipGame
{
    public class Board
    {

        private char[,] grid;

        public Board(int size)
        {
            grid = new char[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    grid[row, col] = '~'; // water
                }
            }
        }
        public void PlaceShip(char shipChar, int row, int col, int size, bool orientation) // True = Horizontal  |  False = Vertical
        {
            if (orientation)
            {
                for (int i = 0; i < size; i++)
                {
                    grid[row, (col + i)] = shipChar;
                }
            }
            else if (!orientation)
            {
                for (int i = 0; i < size; i++)
                {
                    grid[(row + i), col] = shipChar;
                }
            }
        }

        public void Display(bool hideShips)
        {
            for (int row = 0; row < grid.GetLength(0); row++)
            {
                for (int col = 0; col < grid.GetLength(1); col++)
                {
                    char symbol = grid[row, col];

                    // Hide ships if needed
                    if (hideShips && symbol == 'S')
                    {
                        Console.Write("~ ");
                    }
                    else
                    {
                        Console.Write(symbol + " ");
                    }
                }
                Console.WriteLine();
            }
        }
        public void Attack(int row, int col)
        {
            if ((grid[row, col] != '~') && (grid[row, col] != 'O') && (grid[row, col] != 'X'))
            {
                grid[row, col] = 'X'; // hit
                Console.WriteLine("Hit!");
            }
            else if (grid[row, col] == '~')
            {
                grid[row, col] = 'O'; // miss
                Console.WriteLine("Miss!");
            }
        }

        public void Cursor(int row, int col, char cursor)
        {
            grid[row, col] = cursor; // Cursor
            //grid[lastRow, lastCol] = '~'; // Resets Grid Square
        }

        public char Copy(int row, int col)
        {
            return grid[row, col];
        }

        public void Print(int row, int col, char c)
        {
            grid[row, col] = c;
        }
    }
}

