﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipGame
{
    internal class Ship
    {
        private int size;
        private int life;
        private char shipChar;
        private string shipName;

        public Ship(string n, int s)
        {
            if ((s > 0) || (s < 7)) { size = s; life = s; }
            else { size = 1; }

            shipName = n;
            shipChar = shipName[0];
        }

        public string getShipName() { return shipName; }
        public char getShipChar() { return shipChar; }
        public int getShipSize() { return size; }
        public int getShipLife() { return life; }

    }
}