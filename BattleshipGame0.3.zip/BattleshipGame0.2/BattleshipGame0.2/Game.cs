﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BattleshipGame
{
    public class Game
    {
        Board playerBoard;
        Board computerBoard;
        Board monitorBoard;

        List<Ship> playerShips = new List<Ship>
        {
            new Ship("Patrol Boat", 2),
            new Ship("Submarine", 3),
            new Ship("Destroyer", 4)
        };

        List<Ship> computerShips = new List<Ship>();


        public void Start()
        {
            playerBoard = new Board(8);
            computerBoard = new Board(8);
            monitorBoard = new Board(8);

            computerBoard.PlaceShip('S', 2, 3, 3, false);  // Row, Col, Size, Orientation
            //playerBoard.PlaceShip(1, 1, 3, false);     // True = Horizontal  |  False = Vertical

            ShowWelcomeMessage();
            setup();
            RunGameLoop();
            ShowGameOverMessage();
        }

        private void ShowWelcomeMessage()
        {
            Console.WriteLine("=================================");
            Console.WriteLine("         BATTLESHIP GAME         ");
            Console.WriteLine("=================================");
            Console.WriteLine("\nVERSION: 0.3");
            Console.WriteLine("Sink all enemy ships to win!");
            Console.WriteLine();
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();
            Console.Clear();
        }

        private void setup()
        {
            int numships = playerShips.Count;
            bool shipOrient = true; // True = Horizontal  |  False = Vertical

            while (numships > 0)
            {
                bool isSetup = true;

                int x = 0;
                int y = 0;

                string shipName = playerShips[numships - 1].getShipName();
                char shipChar = playerShips[numships - 1].getShipChar();
                int shipLength = playerShips[numships - 1].getShipSize();

                while (isSetup)
                {
                    // Initiate Board & Info
                    monitorBoard.Cursor(y, x, shipChar);
                    Console.WriteLine(numships + " ships left to place.");
                    Console.WriteLine("Use ARROWS to move your ship.");
                    Console.WriteLine("Use SPACEBAR to rotate your ship.");
                    Console.WriteLine("\n--- Player Board ---");
                    monitorBoard.Display(false);
                    Console.WriteLine("\nPlace your " + shipName + ".");
                    Console.WriteLine("\nPress ENTER to place your ship.");

                    // Read input
                    switch (Console.ReadKey().Key)
                    {
                        case ConsoleKey.Enter: isSetup = false; break;
                        case ConsoleKey.Spacebar: if ((y < 9 - shipLength) && (x < 9 - shipLength)) { shipOrient = shipOrient == false; } break;

                        case ConsoleKey.UpArrow: if (y > 0) { y--; }; break;
                        case ConsoleKey.DownArrow: if ((y < 7 && shipOrient) || ((y < (8 - shipLength) && !shipOrient))) { y++; } break;

                        case ConsoleKey.RightArrow: if ((x < 7 && !shipOrient) || ((x < (8 - shipLength)))) { x++; } break;
                        case ConsoleKey.LeftArrow: if (x > 0) { x--; } break;

                        default: break;
                    }

                    // Display playerBoard on monitorBoard
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = 0; j < 8; j++)
                        {
                            monitorBoard.Print(i, j, playerBoard.Copy(i, j));
                        }
                    }

                    // Draw Ship
                    monitorBoard.PlaceShip(shipChar, y, x, shipLength, shipOrient);

                    Console.Clear();
                }

                // Copy ship to Player Board
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        playerBoard.Print(i, j, monitorBoard.Copy(i, j));
                    }
                }

                numships--;
            }
        }

        private void RunGameLoop()
        {
            bool gameOver = false;
            bool playerTurn = true;
            int turnCounter = 1;

            while (!gameOver)
            {
                Console.WriteLine("=================================");
                Console.WriteLine($"Turn #{turnCounter}");
                Console.WriteLine("=================================");

                if (playerTurn)
                {
                    PlayerTurn();

                    Console.WriteLine("\n--- Computer Board ---");
                    computerBoard.Display(true); // hide ships
                }
                else
                {
                    ComputerTurn();

                    Console.WriteLine("\n--- Player Board ---");
                    playerBoard.Display(false); // show ships
                }

                // Temporary win condition (for testing)
                if (turnCounter == 10)
                {
                    gameOver = true;
                }

                playerTurn = !playerTurn;
                turnCounter++;

                Console.WriteLine();
                Console.WriteLine("Press any key for next turn...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        private void PlayerTurn()
        {
            int x = 0;
            int y = 0;
            bool isTurn = true;

            while (isTurn)
            {
                monitorBoard.Cursor(y, x, '*');

                // Display info
                Console.WriteLine("PLAYER TURN");
                Console.WriteLine("Use ARROWS to select target.");
                Console.WriteLine("Use SPACEBAR to fire.");
                Console.WriteLine("\n--- Computer Board ---");
                monitorBoard.Display(false); // hide ships
                Console.WriteLine("\nCurrent selection at " + x + ", " + y);

                // Read input
                switch (Console.ReadKey().Key)
                {
                    case ConsoleKey.Spacebar: computerBoard.Attack(y, x); isTurn = false; break;
                    case ConsoleKey.UpArrow: if (y > 0) { y--; }; break;
                    case ConsoleKey.DownArrow: if (y < 7) { y++; } break;
                    case ConsoleKey.RightArrow: if (x < 7) { x++; } break;
                    case ConsoleKey.LeftArrow: if (x > 0) { x--; } break;
                    default: break;
                }

                // Display playerBoard on monitorBoard
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        monitorBoard.Print(i, j, computerBoard.Copy(i, j));
                    }
                }

                Console.Clear();
            }
        }

        private void ComputerTurn()
        {
            Console.WriteLine("COMPUTER TURN");

            Random rand = new Random();
            int row = rand.Next(0, 8);
            int col = rand.Next(0, 8);

            playerBoard.Attack(row, col);


        }

        private int GetValidNumber(string prompt)
        {
            int number;
            bool valid;

            do
            {
                Console.Write(prompt);
                valid = int.TryParse(Console.ReadLine(), out number);

                if (!valid || number < 0 || number > 7)
                {
                    Console.WriteLine("Invalid input. Enter a number between 0 and 7.");
                }

            } while (!valid || number < 0 || number > 7);

            return number;
        }

        private void ShowGameOverMessage()
        {
            Console.WriteLine("=================================");
            Console.WriteLine("            GAME OVER            ");
            Console.WriteLine("=================================");
        }
    }
}